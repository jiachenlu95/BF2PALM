from package.app import main
main()